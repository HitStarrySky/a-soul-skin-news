## a-soul 动态小助手

- a-soul 动态小助手，提供 a-soul 成员 B 站数据，最新视频动态，新动态提醒。

## 功能

- B 站粉丝数据
- 最新视频动态
- 新视频动态信息提醒

## 支持

- 向晚（Ava）
- 贝拉（Bella）
- 珈乐（Carol）
- 嘉然（Diana）
- 乃琳（Eileen）

## 技术相关

- vue3 + typescript + rollup/gulp
